<?php

/**
* 
*/
class TabSheetControllerClass {
	private $post_type = '';
	
	function __construct(){

		if(get_option('posttype'))
			$this->post_type = get_option('posttype');

		add_action('admin_menu', array($this,'add_menu')); 
		add_action( 'admin_init', array($this,'reg_options') );
		
	}

	static function getInstance(){
		return new TabSheetControllerClass();
	}

	function add_menu(){      
		add_submenu_page( 'options-general.php','Posts Content TabSheet Setting', 'TabSheet setting','manage_options','tabsheet-setting',array($this,'setting_page'));
	} 

	function fetch_post_type(){
		return (!empty($this->post_type))?explode(';',$this->post_type):array();
	}

	

	function reg_options(){      
		register_setting( 'tabsheet-setting', 'posttype' );
	}

	function setting_page(){
		$poststype = get_post_types(array('public'=>true),'objects');
		
		?>
		<div class="wrap">
		<h2>Posts Content TabSheet Setting</h2>

		<form method="post" action="options.php">
		    <?php print_r($posttype);
		     settings_fields( 'tabsheet-setting' ); ?>
		    <?php do_settings_sections( 'tabsheet-setting' ); ?>
		    <table class="form-table">
		        <tr valign="top">
			        <th scope="row">Type Post append</th>
			        <td>
			        	<?php 

			        	?>
			        </td>
		        </tr>
		    </table>
		    
		    <?php submit_button(); ?>

		</form>
		</div>
		<?php
	}

	function editor_post_content(){
		if($this->post_type=='') return;



	}
}