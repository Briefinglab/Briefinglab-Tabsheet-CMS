<?php
/**
 * The file responsible for starting the plugin
 *
 * Manager 
 * *
 * @wordpress-plugin
 * Plugin Name: Briefinglab Tabsheet CMS
 * Contributors: Davide Zorzan
 * Donate link: 
 * Plugin URI: 
 * Description: Add interface to insert data post
 * Version: 1.0.0
 * Author: Davide Zorzan
 * Text Domain: bl-tabsheet-cms
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Domain Path: /langs
 */

// If this file is called directly, then abort execution.
if (!defined('WPINC')) {
    die;
}


require_once plugin_dir_path(__FILE__) . 'controller/class-bl-tabsheet-controller-cms.php';

function run_bl_tabsheet_cms_manager(){

    $tabsheet = new TabSheetControllerClass();

}

// Call the above function to begin execution of the plugin.
run_bl_tabsheet_cms_manager();